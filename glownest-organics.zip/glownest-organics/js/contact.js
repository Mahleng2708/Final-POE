

document.addEventListener('DOMContentLoaded', () => {

    const form = document.getElementById('contactForm');
    if (!form) return;

    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const subjectInput = document.getElementById('subject');
    const messageInput = document.getElementById('message');
    const submitBtn = document.getElementById('submitBtn');
    const feedback = document.getElementById('formFeedback');

    const nameError = document.getElementById('nameError');
    const emailError = document.getElementById('emailError');
    const subjectError = document.getElementById('subjectError');
    const messageError = document.getElementById('messageError');

    /* ---------- REAL-TIME VALIDATION ---------- */
    nameInput.addEventListener('input', () => validateField(nameInput, nameError, validateName));
    emailInput.addEventListener('input', () => validateField(emailInput, emailError, validateEmail));
    subjectInput.addEventListener('change', () => validateField(subjectInput, subjectError, validateSubject));
    messageInput.addEventListener('input', () => validateField(messageInput, messageError, validateMessage));

    function validateName(value) {
        if (!value.trim()) return 'Please enter your full name.';
        if (value.trim().length < 2) return 'Name must be at least 2 characters.';
        return '';
    }

    function validateEmail(value) {
        if (!value.trim()) return 'Please enter your email address.';
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) return 'Please enter a valid email address.';
        return '';
    }

    function validateSubject(value) {
        if (!value) return 'Please choose a subject.';
        return '';
    }

    function validateMessage(value) {
        if (!value.trim()) return 'Please enter your message.';
        if (value.trim().length < 10) return 'Message must be at least 10 characters.';
        return '';
    }

    function validateField(input, errorEl, validator) {
        const error = validator(input.value);
        errorEl.textContent = error;
        if (error) {
            input.classList.add('input-error');
        } else {
            input.classList.remove('input-error');
        }
        return error === '';
    }

    /* ---------- FORM SUBMISSION ---------- */
    form.addEventListener('submit', (e) => {
        e.preventDefault();

        // Validate all fields
        const isNameValid = validateField(nameInput, nameError, validateName);
        const isEmailValid = validateField(emailInput, emailError, validateEmail);
        const isSubjectValid = validateField(subjectInput, subjectError, validateSubject);
        const isMessageValid = validateField(messageInput, messageError, validateMessage);

        if (!isNameValid || !isEmailValid || !isSubjectValid || !isMessageValid) {
            feedback.textContent = 'Please fix the errors above before sending.';
            feedback.className = 'form-feedback error';
            return;
        }

        // Simulate sending (static site — no backend)
        submitBtn.classList.add('loading');
        submitBtn.disabled = true;
        feedback.textContent = 'Sending your message...';
        feedback.className = 'form-feedback';

        setTimeout(() => {
            submitBtn.classList.remove('loading');
            submitBtn.disabled = false;
            feedback.textContent = 'Thank you! Your message has been received. We will get back to you within 24 hours.';
            feedback.className = 'form-feedback success';
            form.reset();

            // Clear all error messages
            [nameError, emailError, subjectError, messageError].forEach(el => el.textContent = '');
            [nameInput, emailInput, subjectInput, messageInput].forEach(el => el.classList.remove('input-error'));

            // Scroll to feedback
            feedback.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 1500);
    });

});